export const Mediaqueries = {
  모바일: "@media screen and (max-width: 640px)",
  태블릿: "@media screen and (max-width: 1024px)",
};
