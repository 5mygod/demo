export const HEADER_HEIGHT = 60;
export const BASE_COLORS = ["#ea002c", "#f47725", "#ffa514", "#ec7568"];
