export const SWIPER_DATA = [
  {
    id: 1,
    name: "행성 1",
    image: "/planet_1_img-min.jpg",
  },
  {
    id: 2,
    name: "행성 2",
    image: "/planet_2_img-min.jpg",
  },
  {
    id: 3,
    name: "행성 3",
    image: "/planet_3_img-min.jpg",
  },
  {
    id: 4,
    name: "행성 4",
    image: "/planet_4_img-min.jpg",
  },
  {
    id: 5,
    name: "행성 5",
    image: "/planet_5_img-min.jpg",
  },
  {
    id: 6,
    name: "행성 6",
    image: "/planet_6_img-min.jpg",
  },
  {
    id: 7,
    name: "행성 7",
    image: "/planet_7_img-min.jpg",
  },
];
